disp('This app just calculates a simple matrix, and has no output');
disp('Any errors at all are unexpected and should be reported');

disp('Calculating 3x3 matrix...');
magic(3)

disp('App finished, feel free to close this window');