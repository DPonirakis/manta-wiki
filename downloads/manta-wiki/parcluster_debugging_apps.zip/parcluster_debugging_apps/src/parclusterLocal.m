filename = 'parclusterDebug.mat';

disp('Checking some paths...');
whichOutput = which('parallel.internal.pool.isPoolThreadWorker', '-all')
save('parclusterDebug.mat', 'whichOutput');

disp('Trying to create parcluster...');
try
    c = parcluster('local');
    disp(['Successfully created parcluster object! Saving to ', filename]);
    save(filename, 'c', '-append');
    clear('c');
catch ME
    warning(['Parcluster error. Saving object to ', filename]);
    % Set whatever other flags you want
    % Log the data by logging the error
    disp(ME);
    save(filename, 'ME', '-append');
end

disp('App finished, feel free to close this window');